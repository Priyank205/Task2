const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();

// Ensure the uploads directory exists
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// Set up multer for file uploads with custom storage options
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir); // Specify the uploads directory
    },
    filename: function (req, file, cb) {
        // Set the file name to be the original name with timestamp
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage, 
    limits: { fileSize: 10 * 1024 * 1024 }, // Limit file size to 10MB
    fileFilter: function (req, file, cb) {
        // Allow only image and PDF files
        const filetypes = /jpg|jpeg|png|gif|pdf/;
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = filetypes.test(file.mimetype);

        if (extname && mimetype) {
            return cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only image and PDF files are allowed.'));
        }
    }
});  // Directory to store uploaded files

// Middleware to parse URL-encoded data (form data)
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve the form on the root route
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/form.html');
});

// Handle form submission with file uploads
app.post('/submit', upload.fields([{ name: 'image' }, { name: 'pdf' }]), (req, res) => {
    const { name, email, password, age } = req.body;
    const image = req.files.image ? req.files.image[0] : null;
    const pdf = req.files.pdf ? req.files.pdf[0] : null;

    // Server-side validation
    if (!name || !email || !password || !age) {
        return res.status(400).send('All fields are required.');
    }

    if (password.length < 6) {
        return res.status(400).send('Password must be at least 6 characters.');
    }

    // Log form data and file details for debugging
    console.log('Form Data:', { name, email, password, age });
    if (image) console.log('Image File:', image);
    if (pdf) console.log('PDF File:', pdf);

    // Respond with success message
    res.send('Form submitted and files uploaded successfully!');
});

// Error handling middleware for file upload errors
app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        // Multer-specific error
        return res.status(400).send(err.message);
    } else if (err) {
        // Other errors (e.g., file type error)
        return res.status(400).send(err.message);
    }
    next();
});

// Set the server to listen on a specified port
const PORT = 5500;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
